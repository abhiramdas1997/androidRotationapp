package com.example.abhi.rotateme;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    public static final Random RANDOM = new Random();
    private View main;
    private ImageView bottle;
    private  int lastangle = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        main = findViewById(R.id.main);
        bottle = (ImageView) findViewById(R.id.bottle);

        main.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                spinbottle();
                sound();
            }
        });

        Toast.makeText(this, "Touch To Rotate Bottle", Toast.LENGTH_LONG).show();
    }

    private void sound() {
        MediaPlayer ring= MediaPlayer.create(MainActivity.this,R.raw.soundtouch);
        ring.start();

    }

    private void spinbottle() {
            int angle = RANDOM.nextInt(3600 - 360) +360;
            float PivotX = bottle.getWidth() /2;
            float PivotY = bottle.getHeight() /2;
            final Animation rotateAnimation = new RotateAnimation(lastangle == -1 ? 0: lastangle ,angle , PivotX,PivotY);
            lastangle = angle;
            rotateAnimation.setDuration(2500);
            rotateAnimation.setFillAfter(true);
            bottle.startAnimation(rotateAnimation);


    }
}
